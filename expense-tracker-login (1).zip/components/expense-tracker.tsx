"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import type { User } from "@supabase/supabase-js"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Member {
  id: string
  name: string
}

interface Expense {
  id: string
  paidBy: string
  amount: number
  description: string
  category: string
  date: string
  addedBy: string
}

interface Balance {
  [key: string]: number
}

interface Settlement {
  from: string
  to: string
  amount: number
}

interface ExpenseTrackerProps {
  user: User
}

interface SavedSession {
  id: string
  name: string
  members: Member[]
  expenses: Expense[]
  savedAt: string
  totalAmount: number
}

export function ExpenseTracker({ user }: ExpenseTrackerProps) {
  const [members, setMembers] = useState<Member[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const [balances, setBalances] = useState<Balance>({})
  const [settlements, setSettlements] = useState<Settlement[]>([])
  const [totalExpenses, setTotalExpenses] = useState(0)
  const [perPersonShare, setPerPersonShare] = useState(0)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [savedSessions, setSavedSessions] = useState<SavedSession[]>([])
  const [sessionName, setSessionName] = useState("")
  const [profileName, setProfileName] = useState("")
  const [profileAvatar, setProfileAvatar] = useState("")
  const [exportStartDate, setExportStartDate] = useState("")
  const [exportEndDate, setExportEndDate] = useState("")
  const [expenseHistory, setExpenseHistory] = useState<any[]>([])

  // Form states
  const [memberName, setMemberName] = useState("")
  const [whoPaid, setWhoPaid] = useState("")
  const [expenseAmount, setExpenseAmount] = useState("")
  const [expenseDescription, setExpenseDescription] = useState("")
  const [expenseCategory, setExpenseCategory] = useState("Other")
  const [dateFilter, setDateFilter] = useState("all")
  const [categoryFilter, setCategoryFilter] = useState("all")

  const router = useRouter()
  const supabase = createClient()
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Load data from localStorage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme")
    if (savedTheme === "dark") {
      setIsDarkMode(true)
      document.documentElement.classList.add("dark")
    }

    const userKey = user.email?.replace("@", "_").replace(".", "_") || "user"
    const savedMembers = localStorage.getItem(`${userKey}_members`)
    const savedExpenses = localStorage.getItem(`${userKey}_expenses`)
    const savedSessionsData = localStorage.getItem(`${userKey}_saved_sessions`)
    const savedProfile = localStorage.getItem(`${userKey}_profile`)
    const savedHistory = localStorage.getItem(`${userKey}_expense_history`)

    if (savedMembers) setMembers(JSON.parse(savedMembers))
    if (savedExpenses) setExpenses(JSON.parse(savedExpenses))
    if (savedSessionsData) setSavedSessions(JSON.parse(savedSessionsData))
    if (savedHistory) setExpenseHistory(JSON.parse(savedHistory))

    if (savedProfile) {
      const profile = JSON.parse(savedProfile)
      setProfileName(profile.name || "")
      setProfileAvatar(profile.avatar || "")
    }
  }, [user.email])

  // Save data to localStorage
  const saveData = () => {
    const userKey = user.email?.replace("@", "_").replace(".", "_") || "user"
    localStorage.setItem(`${userKey}_members`, JSON.stringify(members))
    localStorage.setItem(`${userKey}_expenses`, JSON.stringify(expenses))

    // Auto-save to history if there's meaningful data
    if (members.length > 0 && expenses.length > 0) {
      const historyKey = `${userKey}_expense_history`
      const existingHistory = JSON.parse(localStorage.getItem(historyKey) || "[]")

      // Create a snapshot of current state
      const snapshot = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        members: [...members],
        expenses: [...expenses],
        totalAmount: expenses.reduce((sum, expense) => sum + expense.amount, 0),
      }

      // Add to history (keep last 50 snapshots to prevent storage bloat)
      const updatedHistory = [snapshot, ...existingHistory].slice(0, 50)
      localStorage.setItem(historyKey, JSON.stringify(updatedHistory))
      setExpenseHistory(updatedHistory)
    }
  }

  // Save data whenever state changes
  useEffect(() => {
    if (members.length > 0 || expenses.length > 0) {
      saveData()
    }
  }, [members, expenses]) // Removed collaborators from dependency array

  const saveCurrentSession = () => {
    if (!sessionName.trim()) {
      alert("Please enter a session name")
      return
    }

    if (members.length === 0 || expenses.length === 0) {
      alert("Please add members and expenses before saving")
      return
    }

    const newSession: SavedSession = {
      id: Date.now().toString(),
      name: sessionName.trim(),
      members: [...members],
      expenses: [...expenses],
      savedAt: new Date().toISOString(),
      totalAmount: expenses.reduce((sum, expense) => sum + expense.amount, 0),
    }

    const updatedSessions = [...savedSessions, newSession]
    setSavedSessions(updatedSessions)

    const userKey = user.email?.replace("@", "_").replace(".", "_") || "user"
    localStorage.setItem(`${userKey}_saved_sessions`, JSON.stringify(updatedSessions))

    setSessionName("")
    alert(`Session "${newSession.name}" saved successfully!`)
  }

  const loadSession = (session: SavedSession) => {
    if (confirm(`Load session "${session.name}"? This will replace current data.`)) {
      setMembers(session.members)
      setExpenses(session.expenses)
      setShowResults(false)
      setSidebarOpen(false)
    }
  }

  const deleteSession = (sessionId: string) => {
    const session = savedSessions.find((s) => s.id === sessionId)
    if (confirm(`Delete session "${session?.name}"? This cannot be undone.`)) {
      const updatedSessions = savedSessions.filter((s) => s.id !== sessionId)
      setSavedSessions(updatedSessions)

      const userKey = user.email?.replace("@", "_").replace(".", "_") || "user"
      localStorage.setItem(`${userKey}_saved_sessions`, JSON.stringify(updatedSessions))
    }
  }

  const updateProfile = () => {
    const userKey = user.email?.replace("@", "_").replace(".", "_") || "user"
    const profileData = {
      name: profileName.trim(),
      avatar: profileAvatar.trim(),
    }
    localStorage.setItem(`${userKey}_profile`, JSON.stringify(profileData))
    alert("Profile updated successfully!")
  }

  const exportToCSV = () => {
    let expensesToExport = [...expenses]

    // Filter by date range if specified
    if (exportStartDate || exportEndDate) {
      expensesToExport = expensesToExport.filter((expense) => {
        const expenseDate = new Date(expense.date)
        const startDate = exportStartDate ? new Date(exportStartDate) : new Date(0)
        const endDate = exportEndDate ? new Date(exportEndDate) : new Date()

        return expenseDate >= startDate && expenseDate <= endDate
      })
    }

    if (expensesToExport.length === 0) {
      alert("No expenses found for the selected date range")
      return
    }

    // Create CSV content
    const headers = ["Date", "Paid By", "Description", "Category", "Amount", "Added By"]
    const csvContent = [
      headers.join(","),
      ...expensesToExport.map((expense) =>
        [
          new Date(expense.date).toLocaleDateString(),
          expense.paidBy,
          `"${expense.description}"`,
          expense.category,
          expense.amount.toFixed(2),
          expense.addedBy,
        ].join(","),
      ),
    ].join("\n")

    // Download CSV file
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `expenses_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleLogout = async () => {
    if (confirm("Are you sure you want to logout?")) {
      await supabase.auth.signOut()
      router.push("/auth/login")
    }
  }

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle("dark")
    localStorage.setItem("theme", !isDarkMode ? "dark" : "light")
  }

  const addMember = () => {
    if (!memberName.trim()) {
      alert("Please enter a member name")
      return
    }

    if (members.find((m) => m.name === memberName.trim())) {
      alert("Member already exists")
      return
    }

    const newMember: Member = {
      id: Date.now().toString(),
      name: memberName.trim(),
    }

    setMembers([...members, newMember])
    setMemberName("")
  }

  const removeMember = (memberId: string) => {
    const memberToRemove = members.find((m) => m.id === memberId)
    if (!memberToRemove) return

    setMembers(members.filter((m) => m.id !== memberId))
    setExpenses(expenses.filter((e) => e.paidBy !== memberToRemove.name))
  }

  const addExpense = () => {
    if (!whoPaid) {
      alert("Please select who paid")
      return
    }

    if (!expenseAmount || Number.parseFloat(expenseAmount) <= 0) {
      alert("Please enter a valid amount")
      return
    }

    const newExpense: Expense = {
      id: Date.now().toString(),
      paidBy: whoPaid,
      amount: Number.parseFloat(expenseAmount),
      description: expenseDescription.trim() || "Expense",
      category: expenseCategory,
      date: new Date().toISOString(), // This already includes time
      addedBy: user.email || "user",
    }

    setExpenses([...expenses, newExpense])
    setWhoPaid("")
    setExpenseAmount("")
    setExpenseDescription("")
    setExpenseCategory("Other")
  }

  const calculateSplits = () => {
    if (members.length === 0) {
      alert("Please add at least one member")
      return
    }

    if (expenses.length === 0) {
      alert("Please add at least one expense")
      return
    }

    const total = expenses.reduce((sum, expense) => sum + expense.amount, 0)
    const perPerson = total / members.length

    const newBalances: Balance = {}
    members.forEach((member) => {
      const paid = expenses
        .filter((expense) => expense.paidBy === member.name)
        .reduce((sum, expense) => sum + expense.amount, 0)
      newBalances[member.name] = paid - perPerson
    })

    const newSettlements = generateSettlements(newBalances)

    setBalances(newBalances)
    setSettlements(newSettlements)
    setTotalExpenses(total)
    setPerPersonShare(perPerson)
    setShowResults(true)
  }

  const generateSettlements = (balances: Balance): Settlement[] => {
    const settlements: Settlement[] = []
    const debtors: { person: string; amount: number }[] = []
    const creditors: { person: string; amount: number }[] = []

    Object.entries(balances).forEach(([person, balance]) => {
      if (balance < -0.01) {
        debtors.push({ person, amount: Math.abs(balance) })
      } else if (balance > 0.01) {
        creditors.push({ person, amount: balance })
      }
    })

    debtors.sort((a, b) => b.amount - a.amount)
    creditors.sort((a, b) => b.amount - a.amount)

    let i = 0,
      j = 0
    while (i < debtors.length && j < creditors.length) {
      const debtor = debtors[i]
      const creditor = creditors[j]
      const amount = Math.min(debtor.amount, creditor.amount)

      if (amount > 0.01) {
        settlements.push({
          from: debtor.person,
          to: creditor.person,
          amount: amount,
        })
      }

      debtor.amount -= amount
      creditor.amount -= amount

      if (debtor.amount < 0.01) i++
      if (creditor.amount < 0.01) j++
    }

    return settlements
  }

  const resetData = () => {
    if (confirm("Are you sure you want to reset current data? Your history will be preserved.")) {
      if (members.length > 0 && expenses.length > 0) {
        const userKey = user.email?.replace("@", "_").replace(".", "_") || "user"
        const historyKey = `${userKey}_expense_history`
        const existingHistory = JSON.parse(localStorage.getItem(historyKey) || "[]")

        const finalSnapshot = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          members: [...members],
          expenses: [...expenses],
          totalAmount: expenses.reduce((sum, expense) => sum + expense.amount, 0),
          isResetSnapshot: true, // Mark this as a reset snapshot
        }

        const updatedHistory = [finalSnapshot, ...existingHistory].slice(0, 50)
        localStorage.setItem(historyKey, JSON.stringify(updatedHistory))
        setExpenseHistory(updatedHistory)
      }

      // Clear current data only
      setMembers([])
      setExpenses([])
      setShowResults(false)

      const userKey = user.email?.replace("@", "_").replace(".", "_") || "user"
      localStorage.setItem(`${userKey}_members`, JSON.stringify([]))
      localStorage.setItem(`${userKey}_expenses`, JSON.stringify([]))

      // IMPORTANT: The history key `${userKey}_expense_history` is NEVER cleared
      // IMPORTANT: The saved sessions key `${userKey}_saved_sessions` is NEVER cleared

      alert("Current data reset! Your history has been preserved.")
    }
  }

  const getFilteredExpenses = () => {
    let filtered = [...expenses]

    if (dateFilter !== "all") {
      const now = new Date()
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())

      filtered = filtered.filter((expense) => {
        const expenseDate = new Date(expense.date)

        switch (dateFilter) {
          case "today":
            return expenseDate >= today
          case "week":
            const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
            return expenseDate >= weekAgo
          case "month":
            const monthAgo = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate())
            return expenseDate >= monthAgo
          default:
            return true
        }
      })
    }

    if (categoryFilter !== "all") {
      filtered = filtered.filter((expense) => expense.category === categoryFilter)
    }

    return filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }

  const recentExpenses = expenses.slice(-5).reverse()
  const filteredExpenses = getFilteredExpenses()

  const handleAvatarUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        // 5MB limit
        alert("File size should be less than 5MB")
        return
      }

      if (!file.type.startsWith("image/")) {
        alert("Please select an image file")
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        const result = e.target?.result as string
        setProfileAvatar(result)
      }
      reader.readAsDataURL(file)
    }
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  return (
    <div
      className="min-h-screen p-4 md:p-6"
      style={{
        background: isDarkMode
          ? "linear-gradient(135deg, #1f2937 0%, #111827 50%, #0f172a 100%)"
          : "linear-gradient(135deg, #a8e6cf 0%, #88d8c0 50%, #7fcdcd 100%)",
      }}
    >
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <Card className={`backdrop-blur-sm shadow-xl border-0 mb-6 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}>
          <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
                <SheetTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={`h-9 w-9 p-0 ${isDarkMode ? "border-gray-600 text-gray-300 hover:bg-gray-700" : "border-gray-300 hover:bg-gray-50"}`}
                  >
                    <span className="text-base">☰</span>
                  </Button>
                </SheetTrigger>
                <SheetContent
                  side="left"
                  className="w-80 p-0 border-0"
                  style={{
                    background: isDarkMode
                      ? "linear-gradient(135deg, #1f2937 0%, #111827 50%, #0f172a 100%)"
                      : "linear-gradient(135deg, #a8e6cf 0%, #88d8c0 50%, #7fcdcd 100%)",
                  }}
                >
                  <div className="h-full flex flex-col">
                    <div
                      className={`p-6 backdrop-blur-sm ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"} m-4 rounded-lg shadow-xl`}
                    >
                      <SheetHeader>
                        <SheetTitle
                          className={`flex items-center gap-3 ${isDarkMode ? "text-white" : "text-gray-800"}`}
                        >
                          <div className="w-8 h-8 bg-gradient-to-r from-blue-800 to-blue-600 rounded-lg flex items-center justify-center text-white">
                            ⚙️
                          </div>
                          Dashboard
                        </SheetTitle>
                      </SheetHeader>
                    </div>

                    <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-4">
                      {/* Profile Section */}
                      <Card
                        className={`backdrop-blur-sm shadow-lg border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle
                            className={`text-lg flex items-center gap-2 ${isDarkMode ? "text-white" : "text-gray-800"}`}
                          >
                            <div className="w-6 h-6 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white text-sm">
                              👤
                            </div>
                            Profile
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex items-center gap-4">
                            <div className="relative">
                              <Avatar
                                className="w-16 h-16 ring-2 ring-blue-500/20 cursor-pointer hover:ring-blue-500/40 transition-all"
                                onClick={triggerFileInput}
                              >
                                <AvatarImage src={profileAvatar || "/placeholder.svg"} />
                                <AvatarFallback className="bg-gradient-to-r from-blue-800 to-blue-600 text-white text-lg">
                                  {(profileName || user.email)?.charAt(0).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div
                                className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs cursor-pointer hover:bg-blue-700 transition-colors"
                                onClick={triggerFileInput}
                              >
                                📷
                              </div>
                              <input
                                ref={fileInputRef}
                                type="file"
                                accept="image/*"
                                onChange={handleAvatarUpload}
                                className="hidden"
                              />
                            </div>
                            <div className="flex-1">
                              <Input
                                placeholder="Display name"
                                value={profileName}
                                onChange={(e) => setProfileName(e.target.value)}
                                className={`${isDarkMode ? "bg-gray-700 border-gray-600 text-white" : "bg-white"} focus:ring-2 focus:ring-blue-500/20`}
                              />
                              <p className={`text-xs mt-1 ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                                Click avatar to upload photo
                              </p>
                            </div>
                          </div>
                          <Button
                            onClick={updateProfile}
                            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                          >
                            Update Profile
                          </Button>
                        </CardContent>
                      </Card>

                      {/* Quick Save Section */}
                      <Card
                        className={`backdrop-blur-sm shadow-lg border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle
                            className={`text-lg flex items-center gap-2 ${isDarkMode ? "text-white" : "text-gray-800"}`}
                          >
                            <div className="w-6 h-6 bg-gradient-to-r from-green-600 to-emerald-600 rounded-full flex items-center justify-center text-white text-sm">
                              💾
                            </div>
                            Save Session
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <Input
                            placeholder="Session name"
                            value={sessionName}
                            onChange={(e) => setSessionName(e.target.value)}
                            className={`${isDarkMode ? "bg-gray-700 border-gray-600 text-white" : "bg-white"} focus:ring-2 focus:ring-green-500/20`}
                          />
                          <Button
                            onClick={saveCurrentSession}
                            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                            disabled={members.length === 0 || expenses.length === 0}
                          >
                            💾 Save Current Session
                          </Button>
                        </CardContent>
                      </Card>

                      {/* Saved Sessions */}
                      <Card
                        className={`backdrop-blur-sm shadow-lg border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle
                            className={`text-lg flex items-center gap-2 ${isDarkMode ? "text-white" : "text-gray-800"}`}
                          >
                            <div className="w-6 h-6 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center text-white text-sm">
                              📂
                            </div>
                            Saved Sessions
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 max-h-60 overflow-y-auto">
                            {savedSessions.length === 0 ? (
                              <div
                                className={`text-center p-4 border-2 border-dashed rounded-lg ${isDarkMode ? "border-gray-600 text-gray-400" : "border-gray-300 text-gray-500"}`}
                              >
                                <div className="text-2xl mb-2">📁</div>
                                <p className="text-sm">No saved sessions yet</p>
                              </div>
                            ) : (
                              savedSessions.map((session) => (
                                <div
                                  key={session.id}
                                  className={`p-3 rounded-lg border ${isDarkMode ? "bg-gray-700" : "bg-gray-50"} hover:shadow-md transition-all`}
                                >
                                  <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                      <h4 className={`font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                                        {session.name}
                                      </h4>
                                      <p className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                                        {new Date(session.savedAt).toLocaleDateString()} • ₹
                                        {session.totalAmount.toFixed(2)}
                                      </p>
                                      <p className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                                        {session.members.length} members • {session.expenses.length} expenses
                                      </p>
                                    </div>
                                    <div className="flex gap-1">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => loadSession(session)}
                                        className="text-xs h-7 px-2"
                                      >
                                        Load
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="destructive"
                                        onClick={() => deleteSession(session.id)}
                                        className="text-xs h-7 px-2"
                                      >
                                        ×
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        </CardContent>
                      </Card>

                      {/* History Section */}
                      <Card
                        className={`backdrop-blur-sm shadow-lg border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle
                            className={`text-lg flex items-center gap-2 ${isDarkMode ? "text-white" : "text-gray-800"}`}
                          >
                            <div className="w-6 h-6 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full flex items-center justify-center text-white text-sm">
                              📜
                            </div>
                            Expense History
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 max-h-60 overflow-y-auto">
                            {expenseHistory.length === 0 ? (
                              <div
                                className={`text-center p-4 border-2 border-dashed rounded-lg ${isDarkMode ? "border-gray-600 text-gray-400" : "border-gray-300 text-gray-500"}`}
                              >
                                <div className="text-2xl mb-2">📜</div>
                                <p className="text-sm">No history yet</p>
                                <p className="text-xs mt-1">Add expenses and they'll be auto-saved here</p>
                              </div>
                            ) : (
                              expenseHistory.map((historyItem) => (
                                <div
                                  key={historyItem.id}
                                  className={`p-3 rounded-lg border ${isDarkMode ? "bg-gray-700" : "bg-gray-50"} hover:shadow-md transition-all`}
                                >
                                  <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <h4
                                          className={`font-medium text-sm ${isDarkMode ? "text-white" : "text-gray-800"}`}
                                        >
                                          {historyItem.isResetSnapshot ? "🔄 Reset Snapshot" : "💾 Auto-Save"}
                                        </h4>
                                        {historyItem.isResetSnapshot && (
                                          <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full text-xs">
                                            Reset
                                          </span>
                                        )}
                                      </div>
                                      <p className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                                        {new Date(historyItem.timestamp).toLocaleDateString()} at{" "}
                                        {new Date(historyItem.timestamp).toLocaleTimeString([], {
                                          hour: "2-digit",
                                          minute: "2-digit",
                                        })}
                                      </p>
                                      <p className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                                        {historyItem.members?.length || 0} members • {historyItem.expenses?.length || 0}{" "}
                                        expenses • ₹{historyItem.totalAmount?.toFixed(2) || "0.00"}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                          {expenseHistory.length > 0 && (
                            <div
                              className={`mt-3 p-2 rounded-lg ${isDarkMode ? "bg-green-900/20 border border-green-700/50" : "bg-green-50 border border-green-200"}`}
                            >
                              <p className={`text-xs ${isDarkMode ? "text-green-300" : "text-green-700"}`}>
                                ✅ {expenseHistory.length} history entries preserved
                              </p>
                            </div>
                          )}
                        </CardContent>
                      </Card>

                      {/* Export Section */}
                      <Card
                        className={`backdrop-blur-sm shadow-lg border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle
                            className={`text-lg flex items-center gap-2 ${isDarkMode ? "text-white" : "text-gray-800"}`}
                          >
                            <div className="w-6 h-6 bg-gradient-to-r from-orange-600 to-red-600 rounded-full flex items-center justify-center text-white text-sm">
                              📊
                            </div>
                            Export Data
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="space-y-2">
                            <Label className={`text-sm ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                              Start Date (optional)
                            </Label>
                            <Input
                              type="date"
                              value={exportStartDate}
                              onChange={(e) => setExportStartDate(e.target.value)}
                              className={`${isDarkMode ? "bg-gray-700 border-gray-600 text-white" : "bg-white"} focus:ring-2 focus:ring-orange-500/20`}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className={`text-sm ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                              End Date (optional)
                            </Label>
                            <Input
                              type="date"
                              value={exportEndDate}
                              onChange={(e) => setExportEndDate(e.target.value)}
                              className={`${isDarkMode ? "bg-gray-700 border-gray-600 text-white" : "bg-white"} focus:ring-2 focus:ring-orange-500/20`}
                            />
                          </div>
                          <Button
                            onClick={exportToCSV}
                            className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                            disabled={expenses.length === 0}
                          >
                            📊 Export to CSV
                          </Button>
                        </CardContent>
                      </Card>

                      <Card
                        className={`backdrop-blur-sm shadow-lg border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle
                            className={`text-lg flex items-center gap-2 ${isDarkMode ? "text-white" : "text-gray-800"}`}
                          >
                            <div className="w-6 h-6 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full flex items-center justify-center text-white text-sm">
                              🕒
                            </div>
                            Auto-History
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div
                            className={`p-3 rounded-lg ${isDarkMode ? "bg-indigo-900/20 border border-indigo-700/50" : "bg-indigo-50 border border-indigo-200"}`}
                          >
                            <div className="flex items-center gap-2 mb-2">
                              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                              <span className={`text-sm font-medium ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                                Auto-Save Active
                              </span>
                            </div>
                            <p className={`text-xs ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                              Your expenses are automatically saved as you add them. History is preserved even when you
                              reset current data.
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>

              <div className="relative cursor-pointer" onClick={triggerFileInput}>
                <div className="w-12 h-12 bg-gradient-to-r from-blue-800 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg hover:shadow-lg transition-all">
                  {profileAvatar ? (
                    <img
                      src={profileAvatar || "/placeholder.svg"}
                      alt="Profile"
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    (profileName || user.email)?.charAt(0).toUpperCase()
                  )}
                </div>
              </div>
              <div>
                <CardTitle className={`text-xl ${isDarkMode ? "text-white" : "text-gray-800"}`}>Group Tally</CardTitle>
                <p className={isDarkMode ? "text-gray-300" : "text-gray-600"}>{profileName || user.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={toggleTheme}
                variant="outline"
                size="sm"
                className={`${isDarkMode ? "border-gray-600 text-gray-300 hover:bg-gray-700" : "border-gray-300"}`}
              >
                {isDarkMode ? "☀️" : "🌙"}
              </Button>
              <Button onClick={handleLogout} variant="destructive" size="sm">
                Logout
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Add Members Section */}
          <Card className={`backdrop-blur-sm shadow-xl border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}>
            <CardHeader>
              <CardTitle className={`flex items-center gap-3 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">👥</div>
                Add Members
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Enter member name"
                  value={memberName}
                  onChange={(e) => setMemberName(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && addMember()}
                  className={isDarkMode ? "bg-gray-700 border-gray-600 text-white" : ""}
                />
                <Button
                  onClick={addMember}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  Add
                </Button>
              </div>

              {/* Members List */}
              <div className="flex flex-wrap gap-2">
                {members.length === 0 ? (
                  <div
                    className={`text-center p-4 border-2 border-dashed rounded-lg w-full ${isDarkMode ? "border-gray-600 text-gray-400" : "border-gray-300 text-gray-500"}`}
                  >
                    No members added yet
                  </div>
                ) : (
                  members.map((member) => (
                    <div
                      key={member.id}
                      className="flex items-center gap-2 bg-indigo-600 text-white px-3 py-1 rounded-full text-sm"
                    >
                      {member.name}
                      <button
                        onClick={() => removeMember(member.id)}
                        className="bg-white/20 hover:bg-white/30 rounded-full w-5 h-5 flex items-center justify-center text-xs"
                      >
                        ×
                      </button>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Add Expenses Section */}
          <Card className={`backdrop-blur-sm shadow-xl border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}>
            <CardHeader>
              <CardTitle className={`flex items-center gap-3 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center text-white">💰</div>
                Add Expenses
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className={isDarkMode ? "text-gray-300" : "text-gray-700"}>Who paid?</Label>
                  <Select value={whoPaid} onValueChange={setWhoPaid}>
                    <SelectTrigger className={isDarkMode ? "bg-gray-700 border-gray-600 text-white" : ""}>
                      <SelectValue placeholder="Select member" />
                    </SelectTrigger>
                    <SelectContent>
                      {members.map((member) => (
                        <SelectItem key={member.id} value={member.name}>
                          {member.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className={isDarkMode ? "text-gray-300" : "text-gray-700"}>Amount (₹)</Label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(e.target.value)}
                    className={isDarkMode ? "bg-gray-700 border-gray-600 text-white" : ""}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className={isDarkMode ? "text-gray-300" : "text-gray-700"}>Category</Label>
                  <Select value={expenseCategory} onValueChange={setExpenseCategory}>
                    <SelectTrigger className={isDarkMode ? "bg-gray-700 border-gray-600 text-white" : ""}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Other">Other</SelectItem>
                      <SelectItem value="Food">🍕 Food</SelectItem>
                      <SelectItem value="Travel">✈️ Travel</SelectItem>
                      <SelectItem value="Shopping">🛍️ Shopping</SelectItem>
                      <SelectItem value="Entertainment">🎬 Entertainment</SelectItem>
                      <SelectItem value="Utilities">⚡ Utilities</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className={isDarkMode ? "text-gray-300" : "text-gray-700"}>Description</Label>
                  <Input
                    placeholder="What was this for?"
                    value={expenseDescription}
                    onChange={(e) => setExpenseDescription(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addExpense()}
                    className={isDarkMode ? "bg-gray-700 border-gray-600 text-white" : ""}
                  />
                </div>
              </div>
              <Button
                onClick={addExpense}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
              >
                Add Expense
              </Button>

              {/* Recent Expenses */}
              <div className="space-y-2">
                <h4 className={`font-semibold ${isDarkMode ? "text-white" : "text-gray-800"}`}>Recent Expenses</h4>
                {recentExpenses.length === 0 ? (
                  <div
                    className={`text-center p-4 border-2 border-dashed rounded-lg ${isDarkMode ? "border-gray-600 text-gray-400" : "border-gray-300 text-gray-500"}`}
                  >
                    No expenses added yet
                  </div>
                ) : (
                  recentExpenses.map((expense) => (
                    <div
                      key={expense.id}
                      className={`p-3 rounded-lg border-l-4 border-indigo-500 ${isDarkMode ? "bg-gray-700" : "bg-gray-50"}`}
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <strong className={isDarkMode ? "text-white" : "text-gray-800"}>{expense.paidBy}</strong> paid
                          for <em className={isDarkMode ? "text-gray-300" : "text-gray-600"}>{expense.description}</em>
                          <span className="ml-2 px-2 py-1 bg-indigo-100 text-indigo-800 rounded-full text-xs">
                            {expense.category}
                          </span>
                        </div>
                        <div className="font-bold text-green-600">₹{expense.amount.toFixed(2)}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Calculate & Results Section */}
        <Card className={`backdrop-blur-sm shadow-xl border-0 mb-6 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-3 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
              <div className="w-8 h-8 bg-yellow-600 rounded-lg flex items-center justify-center text-white">🧮</div>
              Calculate & Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4 flex-wrap">
              <Button
                onClick={calculateSplits}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
              >
                Calculate Fair Splits
              </Button>
              <Button onClick={resetData} variant="destructive">
                Reset All Data
              </Button>
            </div>

            {showResults && (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-blue-800 to-blue-600 text-white p-6 rounded-lg text-center">
                  <h3 className="text-2xl font-bold">Total Expenses: ₹{totalExpenses.toFixed(2)}</h3>
                  <p className="text-lg">₹{perPersonShare.toFixed(2)} per person</p>
                </div>

                <div>
                  <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                    Individual Balances
                  </h3>
                  <div className="space-y-2">
                    {Object.entries(balances).map(([person, balance]) => (
                      <div
                        key={person}
                        className={`flex justify-between items-center p-3 rounded-lg ${isDarkMode ? "bg-gray-700" : "bg-gray-50"}`}
                      >
                        <span className={`font-semibold ${isDarkMode ? "text-white" : "text-gray-800"}`}>{person}</span>
                        <span
                          className={`font-bold ${
                            balance > 0.01
                              ? "text-green-600"
                              : balance < -0.01
                                ? "text-red-600"
                                : isDarkMode
                                  ? "text-gray-300"
                                  : "text-gray-600"
                          }`}
                        >
                          {balance > 0.01
                            ? `gets back ₹${balance.toFixed(2)}`
                            : balance < -0.01
                              ? `owes ₹${Math.abs(balance).toFixed(2)}`
                              : "is settled"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                    Simplified Settlements
                  </h3>
                  {settlements.length === 0 ? (
                    <div
                      className={`text-center p-6 border-2 border-dashed rounded-lg ${isDarkMode ? "border-gray-600 text-gray-400" : "border-gray-300 text-gray-500"}`}
                    >
                      Everyone is settled up! 🎉
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {settlements.map((settlement, index) => (
                        <div
                          key={index}
                          className="p-4 bg-yellow-50 border-2 border-yellow-400 rounded-lg text-gray-800 font-semibold"
                        >
                          <strong>{settlement.from}</strong> pays <strong>{settlement.to}</strong>{" "}
                          <strong>₹{settlement.amount.toFixed(2)}</strong>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Expense History Section */}
        <Card className={`backdrop-blur-sm shadow-xl border-0 ${isDarkMode ? "bg-gray-800/95" : "bg-white/95"}`}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-3 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
              <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center text-white">📅</div>
              Expense History
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4 flex-wrap">
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className={`w-40 ${isDarkMode ? "bg-gray-700 border-gray-600 text-white" : ""}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                </SelectContent>
              </Select>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className={`w-40 ${isDarkMode ? "bg-gray-700 border-gray-600 text-white" : ""}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Food">Food</SelectItem>
                  <SelectItem value="Travel">Travel</SelectItem>
                  <SelectItem value="Shopping">Shopping</SelectItem>
                  <SelectItem value="Entertainment">Entertainment</SelectItem>
                  <SelectItem value="Utilities">Utilities</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              {filteredExpenses.length === 0 ? (
                <div
                  className={`text-center p-6 border-2 border-dashed rounded-lg ${isDarkMode ? "border-gray-600 text-gray-400" : "border-gray-300 text-gray-500"}`}
                >
                  No expenses found for selected filters
                </div>
              ) : (
                filteredExpenses.map((expense) => (
                  <div
                    key={expense.id}
                    className={`p-3 rounded-lg border-l-4 border-indigo-500 ${isDarkMode ? "bg-gray-700" : "bg-gray-50"}`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <strong className={isDarkMode ? "text-white" : "text-gray-800"}>{expense.paidBy}</strong> paid
                        for <em className={isDarkMode ? "text-gray-300" : "text-gray-600"}>{expense.description}</em>
                        <span className="ml-2 px-2 py-1 bg-indigo-100 text-indigo-800 rounded-full text-xs">
                          {expense.category}
                        </span>
                        <div className={`text-xs mt-1 ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                          {new Date(expense.date).toLocaleDateString()} at{" "}
                          {new Date(expense.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </div>
                      </div>
                      <div className="font-bold text-green-600">₹{expense.amount.toFixed(2)}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
